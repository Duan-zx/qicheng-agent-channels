﻿[CmdletBinding()]
param([string]$PackageDirectory)

$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($PackageDirectory)) { $PackageDirectory = $PSScriptRoot }
function Check([string]$name, [bool]$ok, [string]$detail) {
    Write-Host ('[{0}] {1}: {2}' -f $(if ($ok) {'通过'} else {'待处理'}), $name, $detail)
}
function Sha256([string]$path) {
    $hash = [Security.Cryptography.SHA256]::Create()
    $stream = [IO.File]::OpenRead($path)
    try { return [BitConverter]::ToString($hash.ComputeHash($stream)).Replace('-','').ToLowerInvariant() }
    finally { $stream.Dispose(); $hash.Dispose() }
}

Write-Host 'Agent Channel 首装预检（只读）'
try {
    $manifestPath = Join-Path $PackageDirectory 'bundle-manifest.json'
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { throw '缺少 bundle-manifest.json' }
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.schemaVersion -ne 1 -or $manifest.product -cne 'Agent Channel trial' -or @($manifest.files).Count -lt 10) { throw 'bundle-manifest.json 无效' }
    $seen = @{}
    foreach ($file in $manifest.files) {
        $relative = [string]$file.path
        if ($relative -notmatch '^(Qicheng-Lite/)?[A-Za-z0-9._/-]+$' -or $relative -match '(^|/)\.\.(/|$)' -or $seen.ContainsKey($relative.ToLowerInvariant())) { throw "清单路径无效：$relative" }
        $seen[$relative.ToLowerInvariant()] = $true
        $path = Join-Path $PackageDirectory $relative
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "缺少包文件：$relative" }
        if ([long](Get-Item -LiteralPath $path).Length -ne [long]$file.bytes -or (Sha256 $path) -cne [string]$file.sha256) { throw "包文件校验失败：$relative" }
    }
    foreach ($required in @('Install-Agent-Channel.cmd','Qicheng-Lite/Install-Qicheng-Lite.ps1','Qicheng-Lite/compose.wechat.yaml','Qicheng-Lite/Dockerfile.wechat')) {
        if (-not $seen.ContainsKey($required.ToLowerInvariant())) { throw "清单缺少：$required" }
    }
    Check '包文件' $true ("$($manifest.liteVersion)，$($manifest.files.Count) 个文件 SHA-256 相符")
} catch {
    Check '包文件' $false $_.Exception.Message
    Write-Host '退出码 2：包缺失或校验失败；请勿安装。'
    exit 2
}

$ready = $true
$windows = [Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT
Check 'Windows 宿主' $windows ([Environment]::OSVersion.VersionString)
if (-not $windows) { $ready = $false }

$docker = Get-Command docker.exe -ErrorAction SilentlyContinue
$dockerReady = $false
if ($docker) {
    try {
        $osType = & $docker.Source info --format '{{.OSType}}' 2>$null
        $infoOkay = $LASTEXITCODE -eq 0 -and [string]$osType -ceq 'linux'
        $endpoint = & $docker.Source context inspect --format '{{.Endpoints.docker.Host}}' 2>$null
        $endpointOkay = $LASTEXITCODE -eq 0 -and [string]$endpoint -match '(?i)^npipe:////\./pipe/(docker_engine|dockerDesktopLinuxEngine)$'
        $hostOkay = [string]::IsNullOrWhiteSpace($env:DOCKER_HOST) -or $env:DOCKER_HOST -match '(?i)^npipe:////\./pipe/(docker_engine|dockerDesktopLinuxEngine)$'
        $dockerReady = $infoOkay -and $endpointOkay -and $hostOkay
    } catch { $dockerReady = $false }
}
Check '本机 Docker Linux engine' $dockerReady $(if ($dockerReady) {'Linux engine 可响应，本机管道'} else {'需启动本机 Docker Linux engine；远端或 Windows engine 不接受'})
if (-not $dockerReady) { $ready = $false }

$release = 0
try { $release = [int](Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release).Release } catch { }
$dotNetReady = $release -ge 378389
Check '.NET Framework 4.x' $dotNetReady $(if ($dotNetReady) {"Release=$release"} else {'未发现 4.x'})
if (-not $dotNetReady) { $ready = $false }

$pythonReady = $false
$pythonText = '未发现 Python 3.10+'
foreach ($name in @('python.exe','py.exe')) {
    $command = Get-Command $name -ErrorAction SilentlyContinue
    if (-not $command) { continue }
    try {
        $version = if ($name -eq 'py.exe') { & $command.Source -3 --version 2>$null } else { & $command.Source --version 2>$null }
        if ($LASTEXITCODE -eq 0 -and [string]$version -match 'Python\s+(\d+)\.(\d+)') {
            if ([int]$matches[1] -eq 3 -and [int]$matches[2] -ge 10) { $pythonReady = $true; $pythonText = [string]$version; break }
        }
    } catch { }
}
Check 'MCP Python 3.10+' $pythonReady $pythonText
if (-not $pythonReady) { $ready = $false }

if (-not $ready) { Write-Host '退出码 3：本机依赖未就绪。'; exit 3 }
Write-Host '退出码 0：包与基础依赖通过；尚未证明安装、频道登录或真实任务可用。'
exit 0

@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Check-DELL-Ready.ps1" %*
set "RESULT=%ERRORLEVEL%"
echo.
if not defined QICHENG_DELL_NO_PAUSE pause
exit /b %RESULT%

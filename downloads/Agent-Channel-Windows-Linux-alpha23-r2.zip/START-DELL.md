# Agent Channel：双频道试用

这是 Windows 宿主上的两个独立 Linux AI 工作区，不要求重装电脑。Windows 客体不是安装前提。此包是私有试用候选，DELL 验收未完成前不作为正式商品发布。

1. 准备已运行的 Docker Desktop（Linux engine）、Python 3.10+；使用 Codex 接入还需要 Codex CLI。Docker、AI 模型和订阅另备，许可由各供应方规定。首次安装需联网构建基础镜像并下载约 195 MB 的固定版本微信工具；实际总下载量更大，不承诺离线首装。
2. 完整解压 ZIP 到普通文件夹，双击 **Install-Agent-Channel.cmd**。入口先校验文件和依赖，再安装两个微信频道。安装期间显示日志路径；失败保留日志，按错误处理，不连续重复安装。
3. 安装后默认后台运行。`Alt+1` 返回本机，`Alt+2/3` 查看频道一/二；托盘也能切换。新频道默认 AI 可操作，主动“接管”或“暂停”后须本人交回，重启保留所选状态。
4. 双击 **Connect-Codex.cmd**，查看预览并确认，重载 Codex。先让 AI 读频道状态和截图，再做一次无业务副作用的输入。两个并行任务各用一个频道；本包默认直连，不提供同频道多任务互斥。已有 Broker 安装不得退回直连。
5. Skill 在 `Qicheng-Lite/skills/agent-channel/SKILL.md`，接入和排错见 `Qicheng-Lite/AI-CLIENTS.zh-CN.md`。Skill 只提供操作规范，不自动注册 MCP 或授予权限。

微信是社区 Linux 移植版。服务端口需按说明开启，账号由本人登录；没有合法小程序项目/AppID 就将编译记为“未测”，启动成功不等于完整微信开发兼容。包内不附腾讯 DEB、Windows 镜像或账号凭据。

程序仍使用兼容目录 `%LOCALAPPDATA%\Programs\QichengLite`，数据目录 `%LOCALAPPDATA%\Qicheng\Lite`；频道资料在 Docker 命名卷 `qicheng-lite-home-1/2`。旧快捷方式名称可能保留“启程”，内部 MCP 名称 `qicheng_lite_1/2` 保持兼容。

停止试用：先保存任务，从托盘退出；需要卸载时运行安装目录中的 **Uninstall-Qicheng-Lite.cmd**，先预览再确认。它停止本产品容器、移除本安装快捷方式，将完整程序与凭据保留在本机恢复目录；资料卷、镜像、用户数据不会删除。恢复目录含私有凭据，不上传网盘或 Git。不要使用 `down -v`。

遇到问题，从开始菜单运行原兼容入口“诊断启程轻量工作台”；它会检查版本、文件清单及频道状态。安装/修复时先退出查看器，使用完整新包，禁止手动覆盖单个程序文件。

请填写 **DELL-RESULTS.md**：首次安装、真实 MCP 输入、双任务、物理热键、画面缩放/点击、接管、宿主重启恢复。只记 DELL 观察，不回传 token、二维码、账号、项目源码或浏览器资料。原包保留，新包校验值见同目录 `SHA256SUMS.txt`。

@echo off
setlocal
call "%~dp0Qicheng-Lite\Register-Qicheng-Codex.cmd"
exit /b %ERRORLEVEL%

@echo off
setlocal
title Install Agent Channel
set "QICHENG_DELL_NO_PAUSE=1"
call "%~dp0Check-DELL-Ready.cmd"
if errorlevel 1 goto preflight_failed
set "RESULT_FILE=%TEMP%\qicheng-dell-install-%RANDOM%-%RANDOM%.txt"
echo Installing two Linux channels. First download and build can take several minutes.
echo Installation log: %RESULT_FILE%
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Run-Agent-ChannelInstall.ps1" -LogPath "%RESULT_FILE%"
set "RESULT=%ERRORLEVEL%"
if "%RESULT%"=="0" powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Read-DELL-InstallResult.ps1" -LogPath "%RESULT_FILE%"
if "%RESULT%"=="0" set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" echo Installation or first launch failed. Keep the error above and read Qicheng-Lite\QUICKSTART.zh-CN.md.
if "%RESULT%"=="0" echo Ready: Alt+1 returns to host, Alt+2 and Alt+3 open channels. Run Connect-Codex.cmd to connect AI.
echo Log retained locally: %RESULT_FILE%
pause
exit /b %RESULT%
:preflight_failed
set "RESULT=%ERRORLEVEL%"
echo Preflight failed. Resolve the dependency or package error above, then retry.
pause
exit /b %RESULT%

﻿[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$LogPath)

$ErrorActionPreference = 'Stop'
try {
    $log = Get-Content -LiteralPath $LogPath -Raw -ErrorAction Stop
    $tail = $log.TrimEnd()
    if (-not $tail.EndsWith('}')) { exit 1 }

    # The installer writes its final JSON after Docker build output. Only an
    # object that consumes the complete log tail can be the final receipt.
    $starts = [regex]::Matches($tail, '(?m)^\s*\{')
    for ($index = $starts.Count - 1; $index -ge 0; $index--) {
        $candidate = $tail.Substring($starts[$index].Index)
        try { $receipt = ConvertFrom-Json -InputObject $candidate -ErrorAction Stop }
        catch { continue }
        if ($receipt -isnot [pscustomobject] -or -not $receipt.PSObject.Properties['status']) { exit 1 }
        switch -CaseSensitive ([string]$receipt.status) {
            'installed' { exit 0 }
            'installed-start-failed' { exit 2 }
            default { exit 1 }
        }
    }
} catch { }
exit 1

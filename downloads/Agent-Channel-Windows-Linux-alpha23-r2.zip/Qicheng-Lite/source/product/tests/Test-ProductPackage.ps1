﻿[CmdletBinding()]
param([switch]$SkipPublicRoundTrip,[switch]$RecoveryOnly,[switch]$HostReturnOnly,[switch]$ConfirmNoInteractive)

$ErrorActionPreference='Stop'
$productRoot=Split-Path -Parent $PSScriptRoot
$moduleRoot=Split-Path -Parent $productRoot
$testRoot=Join-Path ([IO.Path]::GetTempPath()) ('qicheng-lite-product-test-'+[guid]::NewGuid().ToString('N'))
$serverProcess=$null

function Assert-True([bool]$Condition,[string]$Message){if(-not $Condition){throw "ASSERT: $Message"}}
function Read-Json([string]$Path){Get-Content -LiteralPath $Path -Raw -Encoding UTF8|ConvertFrom-Json -ErrorAction Stop}
function Quote-Ps([string]$Value){"'"+$Value.Replace("'","''")+"'"}
function Get-TestOwnedProcesses([string]$Root){
    $prefix=[IO.Path]::GetFullPath($Root).TrimEnd('\')+'\'
    try{
        @(Get-CimInstance Win32_Process -ErrorAction Stop|Where-Object{
            if(-not[string]::IsNullOrWhiteSpace([string]$_.ExecutablePath)){
                try{[IO.Path]::GetFullPath([string]$_.ExecutablePath).StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)}catch{$false}
            }else{$false}
        })
    }catch{@()}
}
function Test-Manifest([string]$Root){
    $manifest=Read-Json (Join-Path $Root 'package-manifest.json')
    $listed=@($manifest.files)
    $actual=@(Get-ChildItem -LiteralPath $Root -Recurse -File|ForEach-Object{$_.FullName.Substring($Root.Length).TrimStart('\').Replace('\','/')}|Where-Object{$_ -ne 'package-manifest.json'})
    Assert-True ($listed.Count -eq $actual.Count) "package manifest count mismatch: $Root"
    foreach($entry in $listed){
        $path=Join-Path $Root ([string]$entry.path)
        Assert-True (Test-Path -LiteralPath $path -PathType Leaf) "manifest file missing: $($entry.path)"
        Assert-True ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -eq [string]$entry.sha256) "manifest hash mismatch: $($entry.path)"
    }
    Assert-True (-not(@($actual|Where-Object{$_ -match '(^|/)(\.local|channel\.token|\.git)(/|$)'}).Count)) 'private state entered package'
    $sourceManifest=Read-Json (Join-Path $Root 'SOURCE-MANIFEST.json')
    foreach($entry in @($sourceManifest.files)){
        $source=Join-Path $Root ('source/'+[string]$entry.path)
        Assert-True ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -eq [string]$entry.sha256) "source manifest hash mismatch: $($entry.path)"
    }
    Assert-True (Test-Path -LiteralPath (Join-Path $Root 'LICENSE')) 'Apache license missing'
    Assert-True (Test-Path -LiteralPath (Join-Path $Root 'THIRD-PARTY-NOTICES.md')) 'third-party notices missing'
    return $manifest
}

try{
    New-Item -ItemType Directory -Path $testRoot|Out-Null
    $output=Join-Path $testRoot 'packages'
    $build=(& (Join-Path $productRoot 'Build-Package.ps1') -OutputDirectory $output|Out-String|ConvertFrom-Json)
    Assert-True ($build.status -eq 'built') 'build did not report built'
    Assert-True ($build.version -eq '0.2.0-alpha.1-local') 'unexpected package version'
    Assert-True (-not $build.dockerBundled) 'package must not claim Docker is bundled'
    Assert-True ([bool]$build.firstBuildRequiresNetwork) 'network boundary missing'
    Assert-True ($build.download -eq 'Qicheng-Lite.zip' -and $build.hostPlatform -eq 'windows-x64' -and $build.guestPlatform -eq 'linux-container') 'download naming or platform contract failed'
    Assert-True (-not $build.linuxHostReleaseBuilt) 'Linux host release must not be emitted'
    foreach($archive in @($build.windows.archive)){Assert-True (Test-Path -LiteralPath $archive -PathType Leaf) "archive missing: $archive"}
    $windowsManifest=Test-Manifest $build.windows.directory
    Assert-True ($windowsManifest.platform -eq 'windows-x64') 'Windows platform mismatch'
    Assert-True ($windowsManifest.guestPlatform -eq 'linux-container') 'guest platform mismatch'
    Assert-True ($windowsManifest.PSObject.Properties.Name -notcontains 'repositoryCommit') 'package manifest leaked Git revision'
    $embeddedSourceManifest=Read-Json (Join-Path $build.windows.directory 'SOURCE-MANIFEST.json')
    Assert-True ($embeddedSourceManifest.PSObject.Properties.Name -notcontains 'repositoryCommit') 'source manifest leaked Git revision'

    $sourcePaths=@((Import-PowerShellDataFile -LiteralPath (Join-Path $productRoot 'Source-Allowlist.psd1')).Files)
    foreach($powerShellSource in @(Get-ChildItem -LiteralPath $moduleRoot -Filter '*.ps1' -Recurse -File)){
        $scriptBytes=[IO.File]::ReadAllBytes($powerShellSource.FullName)
        Assert-True ($scriptBytes.Length -ge 3 -and $scriptBytes[0] -eq 0xEF -and $scriptBytes[1] -eq 0xBB -and $scriptBytes[2] -eq 0xBF) "PowerShell source must use UTF-8 BOM: $($powerShellSource.FullName)"
    }
    $startSource=Get-Content -LiteralPath (Join-Path $build.windows.directory 'source\product\runtime\Start-Qicheng-Lite.ps1') -Raw
    Assert-True ($startSource.Contains('-WaitForHotkeys') -and $startSource.IndexOf('$windowsResult=& $windowsStart -WaitForHotkeys') -lt $startSource.IndexOf('Start-Process -FilePath $viewer -ArgumentList $viewerArguments')) 'Lite viewer can start before Windows hotkeys are released.'
    Assert-True ($startSource.Contains("Parameters.ContainsKey('WaitForHotkeys')") -and $startSource.Contains("legacy-hotkeys-unconfirmed") -and $startSource.Contains('windowsHotkeysConfirmed=$windowsHotkeysConfirmed')) 'Lite cannot recover when an installed Windows viewer lacks hotkey coordination.'
    $diagnoseSource=Get-Content -LiteralPath (Join-Path $build.windows.directory 'source\product\runtime\Diagnose-Qicheng-Lite.ps1') -Raw
    $startParam=[regex]::Match($startSource,'(?s)\bparam\(.*?\)').Value
    $diagnoseParam=[regex]::Match($diagnoseSource,'(?s)\bparam\(.*?\)').Value
    $startHeader=$startSource.Substring(0,$startSource.IndexOf('$ErrorActionPreference'))
    $diagnoseHeader=$diagnoseSource.Substring(0,$diagnoseSource.IndexOf('$ErrorActionPreference'))
    Assert-True ($startParam -and $diagnoseParam -and $startHeader -match 'Port1' -and $startHeader -match 'Port2' -and $diagnoseHeader -match 'Port1' -and $diagnoseHeader -match 'Port2' -and $startSource -match 'Port1 -ne 18761' -and $startSource -match '18761' -and $startSource -match '18762') '固定端口兼容契约缺失'
    $portError=''
    try{& (Join-Path $build.windows.directory 'Start-Qicheng-Lite.ps1') -InstallRoot 'C:\invalid-qicheng-lite' -Port1 19001 -Port2 18762 -ErrorAction Stop|Out-Null}catch{$portError=$_.Exception.Message}
    Assert-True ($portError -match '18761/18762') 'non-contract Lite port was not rejected clearly'
    Assert-True (-not(@($sourcePaths|Where-Object{$_ -match 'PILOT|Start-Pilot|test_pilot|channel_cli'}).Count)) 'private pilot files entered source allowlist'
    $moduleReadme=Get-Content -LiteralPath (Join-Path $moduleRoot 'README.md') -Raw
    Assert-True ($moduleReadme -notmatch 'DELL|NODE01|START-HERE|HANDOFF|jjx|hongyan') 'module README retains private-machine or pilot references'

    $selfTest=Join-Path $testRoot 'viewer-self-test.json'
    $selfTestProcess=Start-Process -FilePath (Join-Path $build.windows.directory 'dist\AgentChannels.exe') -ArgumentList @('--self-test',$selfTest) -Wait -PassThru -WindowStyle Hidden
    Assert-True ($selfTestProcess.ExitCode -eq 0) 'viewer self-test failed'
    $viewerResult=Read-Json $selfTest
    Assert-True ($viewerResult.coordinate_mapping -and $viewerResult.jpeg_route -and $viewerResult.default_hidden -and $viewerResult.single_instance -and $viewerResult.viewer_token_routing) 'viewer contract failed'

    # Exercise the packaged Lite binary's actual pipe client against an isolated same-session server.
    # This does not start either viewer, read a token, or touch the desktop/VM.
    $hostReturnSource=Join-Path $testRoot 'HostReturnProtocol.cs'
    $hostReturnExe=Join-Path $testRoot 'HostReturnProtocol.exe'
    @'
using System;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Reflection;
using System.Threading;

static class HostReturnProtocol {
    static void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
    static int Main(string[] args) {
        Assembly lite = Assembly.LoadFrom(args[0]);
        Type control = lite.GetType("WindowsHostControl", true);
        MethodInfo call = control.GetMethod("ReturnToHost", BindingFlags.Static | BindingFlags.NonPublic);
        Check(call != null, "packaged Lite lacks host return client");
        Test(call, "ok", "ok");
        Test(call, "rejected", "rejected");
        Test(call, "stalled", "timeout");
        Test(call, "missing", "timeout");
        Console.WriteLine("host-return-protocol: passed");
        return 0;
    }
    static void Test(MethodInfo call, string scenario, string expected) {
        string scope = Guid.NewGuid().ToString("N");
        Environment.SetEnvironmentVariable("QICHENG_WINDOWS_VIEWER_TEST_SCOPE", scope);
        string pipeName = "Qicheng.WindowsChannels.Viewer." + Process.GetCurrentProcess().SessionId + ".test." + scope;
        string payload = null;
        Exception serverError = null;
        ManualResetEvent ready = new ManualResetEvent(false);
        Thread server = null;
        if (scenario != "missing") {
            server = new Thread(delegate() {
                try {
                    using (NamedPipeServerStream pipe = new NamedPipeServerStream(pipeName, PipeDirection.InOut, 1)) {
                        ready.Set();
                        pipe.WaitForConnection();
                        using (StreamReader reader = new StreamReader(pipe))
                        using (StreamWriter writer = new StreamWriter(pipe) { AutoFlush = true }) {
                            payload = reader.ReadLine();
                            if (scenario == "stalled") Thread.Sleep(2200);
                            else writer.WriteLine(scenario);
                        }
                    }
                } catch (IOException) { if (scenario != "stalled") serverError = new IOException("server pipe failed"); }
                catch (Exception error) { serverError = error; }
            });
            server.IsBackground = true;
            server.Start();
            Check(ready.WaitOne(1000), "fake server did not become ready");
        }
        Stopwatch timer = Stopwatch.StartNew();
        string result = (string)call.Invoke(null, null);
        timer.Stop();
        Check(result == expected, scenario + " returned " + result);
        Check(timer.ElapsedMilliseconds < 2000, scenario + " blocked too long");
        if (server != null && scenario != "stalled") {
            Check(server.Join(1000), "fake server did not exit");
            Check(serverError == null, "fake server failed: " + serverError);
            Check(payload == "{\"ReturnToHost\":true}", "request did not use explicit host-return protocol");
        }
    }
}
'@|Set-Content -LiteralPath $hostReturnSource -Encoding UTF8
    $hostReturnCompiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
    & $hostReturnCompiler /nologo /target:exe /optimize+ "/out:$hostReturnExe" $hostReturnSource
    Assert-True ($LASTEXITCODE -eq 0) 'host-return protocol harness did not compile'
    $hostReturnOutput=(& $hostReturnExe (Join-Path $build.windows.directory 'dist\AgentChannels.exe')|Out-String)
    Assert-True ($LASTEXITCODE -eq 0 -and $hostReturnOutput -match 'host-return-protocol: passed') 'packaged Lite host-return protocol failed'
    if($HostReturnOnly){
        [ordered]@{schemaVersion=1;status='passed';hostReturnProtocol=$true;missingServerBounded=$true;oldViewerRejected=$true;stalledServerBounded=$true;realDesktopTouched=$false;realVmTouched=$false}|ConvertTo-Json -Depth 4
        return
    }

    $install=Join-Path $testRoot 'installed'
    $data=Join-Path $testRoot 'data'
    $startMenu=Join-Path $testRoot 'start-menu'
    $desktop=Join-Path $testRoot 'desktop'
    $startup=Join-Path $testRoot 'startup'
    $legacyStartup=Join-Path $testRoot 'legacy-startup'
    New-Item -ItemType Directory -Path $startMenu,$desktop,$startup,$legacyStartup|Out-Null
    Set-Content -LiteralPath (Join-Path $legacyStartup '启程 Windows 频道.lnk') -Value 'legacy-shortcut' -NoNewline
    Set-Content -LiteralPath (Join-Path $legacyStartup 'unrelated.lnk') -Value 'unrelated' -NoNewline
    $tokenPath=Join-Path $testRoot 'import.token';$token=-join ('ab'*32)
    [IO.File]::WriteAllText($tokenPath,$token,[Text.UTF8Encoding]::new($false))
    $brokerTokenPath=Join-Path $testRoot 'broker-import.token';$brokerToken=-join ('cd'*32)
    [IO.File]::WriteAllText($brokerTokenPath,$brokerToken,[Text.UTF8Encoding]::new($false))
    $installer=Join-Path $build.windows.directory 'Install-Qicheng-Lite.ps1'
    $installerSource=Get-Content -LiteralPath $installer -Raw
    Assert-True ($installerSource -match '\$legacyRemoved' -and $installerSource -match 'legacyBackup.*legacyLink') 'installer rollback does not restore removed legacy startup shortcut'
    Assert-True ($installerSource -match '\$shortcutSnapshot' -and $installerSource -match 'shortcutSnapshotRoot' -and $installerSource -match '\$managedShortcutPaths' -and $installerSource -match 'shortcut.Exists') 'installer rollback does not restore managed shortcuts'
    $common=@{PackageRoot=$build.windows.directory;InstallRoot=$install;DataRoot=$data;StartMenuRoot=$startMenu;DesktopRoot=$desktop;StartupRoot=$startup;LegacyStartupRoot=$legacyStartup;ImportTokenPath=$tokenPath;ImportBrokerTokenPath=$brokerTokenPath;ChannelCount=2;DisableLegacyWindowsChannelsStartup=$true;Confirm=$false}
    $plan=(& $installer @common|Out-String|ConvertFrom-Json)
    Assert-True ($plan.status -eq 'not-installed' -and -not $plan.hostChangesMade) 'installer plan mutated host state'
    Assert-True ($plan.channelCount -eq 2 -and @($plan.ports).Count -eq 2) 'explicit two-channel plan failed'
    Assert-True (Test-Path -LiteralPath (Join-Path $legacyStartup '启程 Windows 频道.lnk')) 'plan removed legacy shortcut'
    $installText=(& $installer @common -Apply|Out-String)
    Assert-True ($installText -notmatch [regex]::Escape($token) -and $installText -notmatch [regex]::Escape($brokerToken)) 'installer output exposed token'
    $installedResult=$installText|ConvertFrom-Json
    Assert-True ($installedResult.status -eq 'installed' -and $installedResult.legacyStartupDisabled) 'temporary install failed'
    Assert-True ((Get-Content -LiteralPath (Join-Path $install '.local\channel.token') -Raw) -ceq $token) 'imported token mismatch'
    Assert-True ((Get-Content -LiteralPath (Join-Path $install '.local\broker.token') -Raw) -ceq $brokerToken) 'imported broker token mismatch'
    $viewerToken=(Get-Content -LiteralPath (Join-Path $install '.local\viewer.token') -Raw).Trim()
    Assert-True ($viewerToken -match '^[a-f0-9]{64}$' -and $viewerToken -cne $token -and $viewerToken -cne $brokerToken) 'separate viewer token missing or duplicated'
    Assert-True ($installText -notmatch [regex]::Escape($viewerToken)) 'installer output exposed viewer token'
    Assert-True (-not(Test-Path -LiteralPath (Join-Path $legacyStartup '启程 Windows 频道.lnk'))) 'legacy shortcut was not disabled'
    Assert-True (Test-Path -LiteralPath (Join-Path $legacyStartup 'unrelated.lnk')) 'unrelated shortcut changed'
    Assert-True (Test-Path -LiteralPath (Join-Path $data 'compatibility-backup\启程 Windows 频道.lnk')) 'legacy backup missing'
    $shell=New-Object -ComObject WScript.Shell
    function Read-Link([string]$Path){
        Assert-True (Test-Path -LiteralPath $Path -PathType Leaf) "shortcut is missing: $Path"
        $temporaryPath=Join-Path $testRoot ('.qicheng-shortcut-read-'+[guid]::NewGuid().ToString('N')+'.lnk')
        $link=$null
        try{
            Copy-Item -LiteralPath $Path -Destination $temporaryPath
            $link=$shell.CreateShortcut($temporaryPath)
            [pscustomobject]@{Arguments=[string]$link.Arguments;TargetPath=[string]$link.TargetPath;WorkingDirectory=[string]$link.WorkingDirectory}
        }finally{
            if($null -ne $link -and [Runtime.InteropServices.Marshal]::IsComObject($link)){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($link)}
            if(Test-Path -LiteralPath $temporaryPath){Remove-Item -LiteralPath $temporaryPath -Force -ErrorAction SilentlyContinue}
        }
    }
    foreach($linkPath in @((Join-Path $startup '启程轻量工作台.lnk'),(Join-Path $desktop '启程轻量工作台.lnk'),(Join-Path $startMenu '启程轻量工作台.lnk'))){
        $link=Read-Link $linkPath
        Assert-True ($link.Arguments -match '-WindowStyle Hidden' -and $link.Arguments -match '-Background') "background shortcut contract failed: $linkPath"
        Assert-True (($link.Arguments -match '-LoginRecovery') -eq ($linkPath -eq (Join-Path $startup '启程轻量工作台.lnk'))) "login recovery shortcut scope failed: $linkPath"
    }
    $manage=Read-Link (Join-Path $startMenu '管理启程轻量工作台.lnk')
    Assert-True ($manage.Arguments -match '-WindowStyle Hidden' -and $manage.Arguments -notmatch '-Background') 'management shortcut contract failed'
    foreach($channel in 1,2){
        $exportLink=Read-Link (Join-Path $startMenu "取回频道$(@{1='一';2='二'}[$channel])下载文件.lnk")
        Assert-True ($exportLink.Arguments -match '-WindowStyle Hidden' -and $exportLink.Arguments -match "-Channel $channel" -and $exportLink.Arguments -match '-Open') "download export shortcut failed: $channel"
    }
    Assert-True (-not @(Get-ChildItem -LiteralPath $startMenu,$desktop,$startup -Filter '.qicheng-shortcut-*.lnk' -File -ErrorAction SilentlyContinue).Count) 'ASCII temporary shortcut was not cleaned up'

    $legacyCountRecord=Read-Json (Join-Path $install '.qicheng-lite-install.json')
    $legacyCountRecord.PSObject.Properties.Remove('channelCount')
    $legacyCountRecord|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $install '.qicheng-lite-install.json') -Encoding UTF8
    $upgradeCommon=$common.Clone();$upgradeCommon.Remove('ImportTokenPath');$upgradeCommon.Remove('ImportBrokerTokenPath');$upgradeCommon.Remove('DataRoot');$upgradeCommon.Remove('ChannelCount')
    $upgrade=(& $installer @upgradeCommon -Apply|Out-String|ConvertFrom-Json)
    Assert-True ($upgrade.status -eq 'installed') 'upgrade failed'
    Assert-True ($upgrade.channelCount -eq 2 -and (Read-Json (Join-Path $install '.qicheng-lite-install.json')).channelCount -eq 2) 'upgrade did not preserve two-channel selection'
    Assert-True ([string]$upgrade.dataRoot -eq [IO.Path]::GetFullPath($data)) 'upgrade did not inherit custom DataRoot'
    Assert-True ([string](Read-Json (Join-Path $install '.qicheng-lite-install.json')).dataRoot -eq [IO.Path]::GetFullPath($data)) 'upgrade record drifted from custom DataRoot'
    Assert-True ((Get-Content -LiteralPath (Join-Path $install '.local\channel.token') -Raw) -ceq $token) 'upgrade did not preserve token'
    Assert-True ((Get-Content -LiteralPath (Join-Path $install '.local\broker.token') -Raw) -ceq $brokerToken) 'upgrade did not preserve broker token'
    Assert-True ((Get-Content -LiteralPath (Join-Path $install '.local\viewer.token') -Raw).Trim() -ceq $viewerToken) 'upgrade did not preserve viewer token'
    $singleInstall=Join-Path $testRoot 'single-install'
    $singleOptions=@{PackageRoot=$build.windows.directory;InstallRoot=$singleInstall;DataRoot=(Join-Path $testRoot 'single-data');StartMenuRoot=(Join-Path $testRoot 'single-menu');DesktopRoot=(Join-Path $testRoot 'single-desktop');StartupRoot=(Join-Path $testRoot 'single-startup');LegacyStartupRoot=(Join-Path $testRoot 'single-legacy');Confirm=$false}
    $singlePlan=(& $installer @singleOptions|Out-String|ConvertFrom-Json)
    Assert-True ($singlePlan.channelCount -eq 1 -and @($singlePlan.ports).Count -eq 1) 'fresh installation did not default to one channel'
    $singleResult=(& $installer @singleOptions -Apply|Out-String|ConvertFrom-Json)
    Assert-True ($singleResult.channelCount -eq 1 -and (Read-Json (Join-Path $singleInstall '.qicheng-lite-install.json')).channelCount -eq 1) 'one-channel install record failed'
    Assert-True (-not(Test-Path -LiteralPath (Join-Path $singleOptions.StartMenuRoot '取回频道二下载文件.lnk'))) 'disabled channel download shortcut was created'
    $singleUpgrade=(& $installer @singleOptions -Apply|Out-String|ConvertFrom-Json)
    Assert-True ($singleUpgrade.channelCount -eq 1) 'one-channel upgrade did not preserve selection'
    $twoPlan=(& $installer @singleOptions -ChannelCount 2|Out-String|ConvertFrom-Json)
    Assert-True ($twoPlan.channelCount -eq 2 -and @($twoPlan.ports).Count -eq 2) 'two-channel expansion plan failed'
    $twoResult=(& $installer @singleOptions -ChannelCount 2 -Apply|Out-String|ConvertFrom-Json)
    Assert-True ($twoResult.channelCount -eq 2 -and (Test-Path -LiteralPath (Join-Path $singleOptions.StartMenuRoot '取回频道二下载文件.lnk'))) 'two-channel expansion failed'
    $singleAgain=(& $installer @singleOptions -ChannelCount 1 -Apply|Out-String|ConvertFrom-Json)
    Assert-True ($singleAgain.channelCount -eq 1 -and -not(Test-Path -LiteralPath (Join-Path $singleOptions.StartMenuRoot '取回频道二下载文件.lnk'))) 'two-to-one selection or shortcut removal failed'
    $restore=(& (Join-Path $install 'Restore-LegacyWindowsChannelsStartup.ps1') -InstallRoot $install -LegacyStartupRoot $legacyStartup -Apply -Confirm:$false|Out-String|ConvertFrom-Json)
    Assert-True ($restore.status -eq 'restored' -and $restore.backupPreserved) 'legacy shortcut restore failed'
    Assert-True (Test-Path -LiteralPath (Join-Path $legacyStartup 'unrelated.lnk')) 'restore changed unrelated shortcut'

    $fakeDocker=Join-Path $testRoot 'fake-docker.exe'
    $dockerLog=Join-Path $testRoot 'docker.log';$env:QICHENG_LITE_FAKE_DOCKER_LOG=$dockerLog
    $fakeDockerSource=Join-Path $testRoot 'FakeDocker.cs'
    [IO.File]::WriteAllText($fakeDockerSource,@'
using System;
using System.IO;
using System.Threading;
static class FakeDocker {
    static int Main(string[] args) {
        string mode=Environment.GetEnvironmentVariable("QICHENG_LITE_FAKE_DOCKER_MODE");
        if (mode=="hang") Thread.Sleep(3000);
        File.AppendAllText(Environment.GetEnvironmentVariable("QICHENG_LITE_FAKE_DOCKER_LOG"),String.Join(" ",args)+Environment.NewLine);
        if (args.Length>0 && args[0]=="context") { if (mode=="context-fail") return 1; Console.WriteLine(mode=="remote" ? "tcp://example.invalid:2375" : "npipe:////./pipe/dockerDesktopLinuxEngine"); return 0; }
        if (args.Length>0 && args[0]=="info") {
            string marker=Environment.GetEnvironmentVariable("QICHENG_LITE_FAKE_DESKTOP_MARKER");
            if (!String.IsNullOrEmpty(marker) && !File.Exists(marker)) return 1;
            Console.WriteLine(mode=="windows" ? "windows" : "linux"); return 0;
        }
        if (args.Length>0 && args[0]=="version") { Console.WriteLine("1.0"); return 0; }
        if (args.Length>1 && args[0]=="image" && args[1]=="inspect") { if (mode=="no-image") return 1; Console.WriteLine(mode=="replaced-tag" ? "sha256:replacement" : "sha256:fixture-image"); return 0; }
        string ownedInstall=Environment.GetEnvironmentVariable("QICHENG_LITE_FAKE_OWNED_INSTALL");
        if (!String.IsNullOrEmpty(ownedInstall)) {
            if (args[0]=="compose" && Array.IndexOf(args,"ps")>=0) { Console.WriteLine("owned-"+args[args.Length-1]); return 0; }
            if (args[0]=="inspect") {
                string format=String.Join(" ",args);
                if (format.Contains("{{index .Config.Labels ") && !format.Contains("\"")) return 1;
                if (format.Contains("{{.Image}}")) Console.WriteLine("sha256:fixture-image");
                else if (format.Contains("{{json .Config.Labels}}")) {
                    if (mode=="labels-fail") return 1;
                    if (mode=="bad-labels") Console.WriteLine("{invalid");
                    else Console.WriteLine("{\"com.docker.compose.project\":\"qicheng-agent-channels\",\"com.docker.compose.service\":\"channel1\",\"com.docker.compose.project.working_dir\":\""+ownedInstall.Replace("\\","\\\\").Replace("\"","\\\"")+"\"}");
                }
                else if (format.Contains("project.working_dir")) Console.WriteLine(mode=="foreign-owner" ? @"C:\foreign-lite" : ownedInstall);
                else if (format.Contains("com.docker.compose.project")) Console.WriteLine("qicheng-agent-channels");
                else if (format.Contains("com.docker.compose.service")) Console.WriteLine("channel1");
                else if (format.Contains("{{json .Mounts}}")) {
                    string bindName=mode=="split-volume-identity" ? "qicheng-lite-home-1" : "other";
                    string homeName=mode=="foreign-volume" || mode=="split-volume-identity" ? "foreign-home" : "qicheng-lite-home-1";
                    Console.WriteLine("[{\"Type\":\"bind\",\"Name\":\""+bindName+"\",\"Destination\":\"/tmp\"},{\"Type\":\"volume\",\"Name\":\""+homeName+"\",\"Destination\":\"/home/channel\"},{\"Type\":\"bind\",\"Name\":\"config\",\"Destination\":\"/app/config\"},{\"Type\":\"volume\",\"Name\":\"cache\",\"Destination\":\"/cache\"}]");
                }
                return 0;
            }
            if (args[0]=="create") { Console.WriteLine("aaaaaaaaaaaa"); return 0; }
            if (args[0]=="cp") {
                string source=Environment.GetEnvironmentVariable("QICHENG_LITE_FAKE_IMAGE_APP");
                string destination=args[args.Length-1];
                foreach(string file in Directory.GetFiles(source,"*",SearchOption.AllDirectories)) {
                    string target=Path.Combine(destination,file.Substring(source.Length).TrimStart(Path.DirectorySeparatorChar));
                    Directory.CreateDirectory(Path.GetDirectoryName(target));File.Copy(file,target,true);
                }
                if(mode=="image-mismatch") File.AppendAllText(Path.Combine(destination,"server.py"),"\n# stale image");
                return 0;
            }
            if (args[0]=="rm") return mode=="rm-fail" ? 1 : 0;
        }
        string oldDirectory=Environment.GetEnvironmentVariable("QICHENG_LITE_FAKE_OLD_CHANNEL2_DIR");
        if (!String.IsNullOrEmpty(oldDirectory) && args.Length>0 && args[0]=="compose" && Array.IndexOf(args,"ps")>=0 && Array.IndexOf(args,"channel2")>=0) { Console.WriteLine("old-channel2-id"); return 0; }
        if (!String.IsNullOrEmpty(oldDirectory) && args.Length>0 && args[0]=="inspect") { Console.WriteLine(oldDirectory); return 0; }
        return 0;
    }
}
'@,[Text.UTF8Encoding]::new($false))
    $compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
    & $compiler /nologo /target:exe /optimize+ "/out:$fakeDocker" $fakeDockerSource
    Assert-True ($LASTEXITCODE -eq 0) 'fake Docker compilation failed'
    $port1=18761;$port2=18762
    $cmdInstall=Join-Path $testRoot 'cmd-installed';$cmdData=Join-Path $testRoot 'cmd-data';$cmdRunner=Join-Path $testRoot 'run-installer.cmd'
    @"
@echo off
set QICHENG_LITE_NO_PAUSE=1
call "$($build.windows.directory)\Install-Qicheng-Lite.cmd" -InstallRoot "$cmdInstall" -DataRoot "$cmdData" -StartMenuRoot "$($testRoot)\cmd-menu" -DesktopRoot "$($testRoot)\cmd-desktop" -StartupRoot "$($testRoot)\cmd-startup" -LegacyStartupRoot "$($testRoot)\cmd-legacy" -ImportTokenPath "$tokenPath" -DockerPath "$fakeDocker" -HealthAttempts 1
exit /b %ERRORLEVEL%
"@|Set-Content -LiteralPath $cmdRunner -Encoding ASCII
    $cmdOutput=(& cmd.exe /d /c $cmdRunner 2>&1|Out-String);$cmdExit=$LASTEXITCODE
    Assert-True ($cmdExit -eq 2) "double-click installer did not return startup-failed exit code (exit=$cmdExit; output=$cmdOutput)"
    Assert-True ($cmdOutput -match 'installed-start-failed' -and $cmdOutput -match 'was installed, but its first backend build or health check failed') 'double-click installer did not explain retained install and startup failure'
    Assert-True ($cmdOutput -notmatch 'installation finished') 'double-click installer printed false success after startup failure'
    Assert-True (Test-Path -LiteralPath (Join-Path $cmdInstall '.qicheng-lite-install.json')) 'startup failure did not retain installation'
    Assert-True ((Get-Content -LiteralPath $dockerLog -Raw) -match '--build') 'normal double-click installation did not request a backend build'
    if($RecoveryOnly){
        $env:QICHENG_TEST_INPUT_AUTH='direct-v1'
        $global:mockStateUris=New-Object 'System.Collections.Generic.List[string]'
        function Invoke-RestMethod { param([string]$Uri,[hashtable]$Headers,[int]$TimeoutSec) $global:mockStateUris.Add($Uri); [pscustomobject]@{input_target='private-linux-display';input_auth=$env:QICHENG_TEST_INPUT_AUTH;channel_id=if($Uri -match ':18761/'){'1'}else{'2'};width=1600;height=900} }
        $freshOptions=$singleOptions.Clone();$freshOptions.InstallRoot=Join-Path $testRoot 'fresh-offline'
        $freshOfflineError=''
        try{& $installer @freshOptions -ReuseExistingBackendImage -ErrorAction Stop|Out-Null}catch{$freshOfflineError=$_.Exception.Message}
        Assert-True ($freshOfflineError -match '首次安装必须构建' -and -not(Test-Path -LiteralPath $freshOptions.InstallRoot)) "offline image reuse accepted a fresh installation: $freshOfflineError"
        Copy-Item -LiteralPath (Join-Path $build.windows.directory 'backend') -Destination $testRoot -Recurse
        $env:QICHENG_LITE_FAKE_IMAGE_APP=Join-Path $testRoot 'backend'
        $env:QICHENG_LITE_FAKE_OWNED_INSTALL=$singleInstall
        $recordPath=Join-Path $singleInstall '.qicheng-lite-install.json'
        $recordHold=Join-Path $singleInstall '.qicheng-lite-install.hold'
        Move-Item -LiteralPath $recordPath -Destination $recordHold
        try{
            $missingRecordError=''
            try{& $installer @singleOptions -ReuseExistingBackendImage -ErrorAction Stop|Out-Null}catch{$missingRecordError=$_.Exception.Message}
            Assert-True ($missingRecordError -match '首次安装必须构建') 'offline image reuse accepted an installation without its record'
        }finally{Move-Item -LiteralPath $recordHold -Destination $recordPath}
        $oldBackend=Join-Path $singleInstall 'backend\server.py'
        $oldBackendBytes=[IO.File]::ReadAllBytes($oldBackend)
        try{
            Add-Content -LiteralPath $oldBackend -Value '# changed backend'
            $changedBackendError=''
            try{& $installer @singleOptions -ReuseExistingBackendImage -ErrorAction Stop|Out-Null}catch{$changedBackendError=$_.Exception.Message}
            Assert-True ($changedBackendError -match '原 manifest 校验' -and (Test-Path -LiteralPath (Join-Path $singleInstall '.qicheng-lite-install.json'))) 'changed backend silently reused the image'
        }finally{[IO.File]::WriteAllBytes($oldBackend,$oldBackendBytes)}
        $env:QICHENG_LITE_FAKE_DOCKER_MODE='remote'
        $remoteInstallError=''
        try{& $installer @singleOptions -ReuseExistingBackendImage -DockerPath $fakeDocker -Apply -ErrorAction Stop|Out-Null}catch{$remoteInstallError=$_.Exception.Message}
        Assert-True ($remoteInstallError -match '本机 Docker endpoint' -and (Test-Path -LiteralPath $recordPath)) 'remote endpoint passed offline preflight'
        $env:QICHENG_LITE_FAKE_DOCKER_MODE='replaced-tag'
        $replacedTagError=''
        try{& $installer @singleOptions -ReuseExistingBackendImage -DockerPath $fakeDocker -Apply -ErrorAction Stop|Out-Null}catch{$replacedTagError=$_.Exception.Message}
        Assert-True ($replacedTagError -match '镜像或 Compose 归属不匹配' -and (Test-Path -LiteralPath $recordPath)) 'replaced image tag passed offline preflight'
        $env:QICHENG_LITE_FAKE_DOCKER_MODE='foreign-owner'
        $env:QICHENG_LITE_FAKE_OWNED_INSTALL='C:\foreign-lite'
        $foreignOwnerError=''
        try{& $installer @singleOptions -ReuseExistingBackendImage -DockerPath $fakeDocker -Apply -ErrorAction Stop|Out-Null}catch{$foreignOwnerError=$_.Exception.Message}
        Assert-True ($foreignOwnerError -match '镜像或 Compose 归属不匹配' -and (Test-Path -LiteralPath $recordPath)) 'foreign Compose owner passed offline preflight'
        $env:QICHENG_LITE_FAKE_OWNED_INSTALL=$singleInstall
        $env:QICHENG_LITE_FAKE_DOCKER_MODE='labels-fail'
        $labelExitError=''
        try{& $installer @singleOptions -ReuseExistingBackendImage -DockerPath $fakeDocker -Apply -ErrorAction Stop|Out-Null}catch{$labelExitError=$_.Exception.Message}
        Assert-True ($labelExitError -match '镜像或 Compose 归属不匹配' -and (Test-Path -LiteralPath $recordPath)) 'failed label inspect was overwritten by later successful inspect'
        $env:QICHENG_LITE_FAKE_DOCKER_MODE='bad-labels'
        $badLabelError=''
        try{& $installer @singleOptions -ReuseExistingBackendImage -DockerPath $fakeDocker -Apply -ErrorAction Stop|Out-Null}catch{$badLabelError=$_.Exception.Message}
        Assert-True ($badLabelError -match 'Compose 标签无效' -and (Test-Path -LiteralPath $recordPath)) 'invalid label JSON passed offline preflight'
        $env:QICHENG_LITE_FAKE_DOCKER_MODE='foreign-volume'
        $foreignVolumeError=''
        try{& $installer @singleOptions -ReuseExistingBackendImage -DockerPath $fakeDocker -Apply -ErrorAction Stop|Out-Null}catch{$foreignVolumeError=$_.Exception.Message}
        Assert-True ($foreignVolumeError -match '持久卷归属不匹配' -and (Test-Path -LiteralPath $recordPath)) 'foreign volume passed offline preflight'
        $env:QICHENG_LITE_FAKE_DOCKER_MODE='split-volume-identity'
        $splitVolumeError=''
        try{& $installer @singleOptions -ReuseExistingBackendImage -DockerPath $fakeDocker -Apply -ErrorAction Stop|Out-Null}catch{$splitVolumeError=$_.Exception.Message}
        Assert-True ($splitVolumeError -match '持久卷归属不匹配' -and (Test-Path -LiteralPath $recordPath)) 'Compose volume identity was assembled from different mounts'
        $env:QICHENG_LITE_FAKE_DOCKER_MODE='image-mismatch'
        $imageMismatchError=''
        try{& $installer @singleOptions -ReuseExistingBackendImage -DockerPath $fakeDocker -Apply -ErrorAction Stop|Out-Null}catch{$imageMismatchError=$_.Exception.Message}
        Assert-True ($imageMismatchError -match '镜像内后端文件不匹配' -and (Test-Path -LiteralPath $recordPath)) 'wrong image bytes passed offline preflight'
        $env:QICHENG_LITE_FAKE_DOCKER_MODE='rm-fail'
        $cleanupError=''
        try{& $installer @singleOptions -ReuseExistingBackendImage -DockerPath $fakeDocker -Apply -ErrorAction Stop|Out-Null}catch{$cleanupError=$_.Exception.Message}
        Assert-True ($cleanupError -match '镜像探针清理失败' -and $cleanupError -match 'probeContainerId=aaaaaaaaaaaa' -and (Test-Path -LiteralPath $recordPath)) 'failed probe container cleanup did not block installation or report its ID'
        Remove-Item Env:QICHENG_LITE_FAKE_DOCKER_MODE
        $temporaryBase=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\')
        $probeBefore=@(Get-ChildItem -LiteralPath $temporaryBase -Directory -Filter 'qicheng-lite-image-check-*'|ForEach-Object{$_.FullName})
        function Remove-Item { throw 'injected probe directory cleanup failure' }
        $directoryCleanupError=''
        try{& $installer @singleOptions -ReuseExistingBackendImage -DockerPath $fakeDocker -Apply -ErrorAction Stop|Out-Null}catch{$directoryCleanupError=$_.Exception.Message}
        finally{Microsoft.PowerShell.Management\Remove-Item -LiteralPath Function:\Remove-Item -Force}
        $probeLeft=@(Get-ChildItem -LiteralPath $temporaryBase -Directory -Filter 'qicheng-lite-image-check-*'|Where-Object{$probeBefore -notcontains $_.FullName})
        Assert-True ($directoryCleanupError -match '镜像探针清理失败' -and $directoryCleanupError -match 'probeContainerId=aaaaaaaaaaaa' -and $probeLeft.Count -eq 1 -and (Test-Path -LiteralPath $recordPath)) 'failed probe directory cleanup did not block installation'
        foreach($left in $probeLeft){
            $resolvedLeft=[IO.Path]::GetFullPath($left.FullName)
            Assert-True ([IO.Path]::GetDirectoryName($resolvedLeft).Equals($temporaryBase,[StringComparison]::OrdinalIgnoreCase) -and [IO.Path]::GetFileName($resolvedLeft) -match '^qicheng-lite-image-check-[0-9a-f]{32}$') 'injected probe cleanup path escaped temporary root'
            Microsoft.PowerShell.Management\Remove-Item -LiteralPath $resolvedLeft -Recurse -Force
        }
        $env:QICHENG_LITE_FAKE_DOCKER_MODE='no-image'
        $missingImageError=''
        try{& $installer @singleOptions -ReuseExistingBackendImage -DockerPath $fakeDocker -ErrorAction Stop|Out-Null}catch{$missingImageError=$_.Exception.Message}
        Assert-True ($missingImageError -match '本地缺少' -and (Test-Path -LiteralPath (Join-Path $singleInstall '.qicheng-lite-install.json'))) 'missing local image was accepted'
        Remove-Item Env:QICHENG_LITE_FAKE_DOCKER_MODE
        $oldDockerfile=Join-Path $singleInstall 'Dockerfile'
        $themeDockerfile=[IO.File]::ReadAllText($oldDockerfile)
        [IO.File]::WriteAllText($oldDockerfile,$themeDockerfile.Replace(' SCREEN_HEIGHT=900 GTK_THEME=Adwaita:dark',' SCREEN_HEIGHT=900'))
        $oldPackageManifestPath=Join-Path $singleInstall 'package-manifest.json'
        $oldPackageManifest=Read-Json $oldPackageManifestPath
        $dockerfileEntry=@($oldPackageManifest.files|Where-Object{$_.path -eq 'Dockerfile'})[0]
        $dockerfileEntry.sha256=(Get-FileHash -LiteralPath $oldDockerfile -Algorithm SHA256).Hash.ToLowerInvariant()
        $oldPackageManifest|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $oldPackageManifestPath -Encoding UTF8
        Add-Content -LiteralPath $oldDockerfile -Value '# changed Dockerfile'
        $dockerfileEntry.sha256=(Get-FileHash -LiteralPath $oldDockerfile -Algorithm SHA256).Hash.ToLowerInvariant()
        $oldPackageManifest|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $oldPackageManifestPath -Encoding UTF8
        $changedDockerfileError=''
        try{& $installer @singleOptions -ReuseExistingBackendImage -DockerPath $fakeDocker -ErrorAction Stop|Out-Null}catch{$changedDockerfileError=$_.Exception.Message}
        Assert-True ($changedDockerfileError -match 'Dockerfile 后端构建内容已变化') 'changed Dockerfile silently reused the image'
        [IO.File]::WriteAllText($oldDockerfile,$themeDockerfile.Replace(' SCREEN_HEIGHT=900 GTK_THEME=Adwaita:dark',' SCREEN_HEIGHT=900'))
        $dockerfileEntry.sha256=(Get-FileHash -LiteralPath $oldDockerfile -Algorithm SHA256).Hash.ToLowerInvariant()
        $oldPackageManifest|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $oldPackageManifestPath -Encoding UTF8
        Remove-Item -LiteralPath $dockerLog -Force
        $offlinePlan=(& $installer @singleOptions -ReuseExistingBackendImage -DockerPath $fakeDocker|Out-String|ConvertFrom-Json)
        $previewCalls=Get-Content -LiteralPath $dockerLog -Raw
        Assert-True ($offlinePlan.status -eq 'upgrade-preview' -and $offlinePlan.backendImageAction -eq 'reuse-local-image' -and -not $offlinePlan.imageContentVerified -and -not $offlinePlan.hostChangesMade -and $previewCalls -notmatch '(^|\s)(create|cp|rm)(\s|$)') 'offline preview mutated Docker or claimed image content verification'
        $ps5PlanText=(& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installer -PackageRoot $build.windows.directory -InstallRoot $singleInstall -DataRoot $singleOptions.DataRoot -StartMenuRoot $singleOptions.StartMenuRoot -DesktopRoot $singleOptions.DesktopRoot -StartupRoot $singleOptions.StartupRoot -LegacyStartupRoot $singleOptions.LegacyStartupRoot -ReuseExistingBackendImage -DockerPath $fakeDocker|Out-String)
        $ps5PlanExit=$LASTEXITCODE
        Assert-True ($ps5PlanExit -eq 0 -and ($ps5PlanText|ConvertFrom-Json).status -eq 'upgrade-preview') 'PowerShell 5.1 offline reuse preview could not read Docker Compose labels'
        $env:QICHENG_LITE_FAKE_DOCKER_MODE='split-volume-identity'
        $savedErrorActionPreference=$ErrorActionPreference
        try{
            # In Windows PowerShell 5.1, redirected native stderr becomes a
            # NativeCommandError when EAP is Stop. Capture this expected error.
            $ErrorActionPreference='Continue'
            $ps5SplitText=(& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installer -PackageRoot $build.windows.directory -InstallRoot $singleInstall -DataRoot $singleOptions.DataRoot -StartMenuRoot $singleOptions.StartMenuRoot -DesktopRoot $singleOptions.DesktopRoot -StartupRoot $singleOptions.StartupRoot -LegacyStartupRoot $singleOptions.LegacyStartupRoot -ReuseExistingBackendImage -DockerPath $fakeDocker 2>&1|Out-String)
            $ps5SplitExit=$LASTEXITCODE
        }finally{$ErrorActionPreference=$savedErrorActionPreference}
        Assert-True ($ps5SplitExit -ne 0 -and (Test-Path -LiteralPath $recordPath) -and $ps5SplitText -match '持久卷归属不匹配') 'PowerShell 5.1 did not reject the mismatched volume for the expected reason'
        Remove-Item Env:QICHENG_LITE_FAKE_DOCKER_MODE
        Remove-Item -LiteralPath $dockerLog -Force
        $whatIfText=(& $installer @singleOptions -ReuseExistingBackendImage -DockerPath $fakeDocker -Apply -WhatIf|Out-String)
        $whatIfCalls=Get-Content -LiteralPath $dockerLog -Raw
        Assert-True ($whatIfText -match 'imageContentVerified' -and $whatIfText -match 'false' -and $whatIfCalls -notmatch '(^|\s)(create|cp|rm)(\s|$)' -and (Test-Path -LiteralPath $recordPath)) 'Apply -WhatIf created an image probe or changed the install'
        if($ConfirmNoInteractive){
            Remove-Item -LiteralPath $dockerLog -Force
            $confirmOptions=$singleOptions.Clone();$confirmOptions.Remove('Confirm')
            $confirmText=(& $installer @confirmOptions -ReuseExistingBackendImage -DockerPath $fakeDocker -Apply -Confirm|Out-String)
            $confirmCalls=Get-Content -LiteralPath $dockerLog -Raw
            Assert-True ($confirmText -match 'imageContentVerified' -and $confirmText -match 'false' -and $confirmCalls -notmatch '(^|\s)(create|cp|rm)(\s|$)' -and (Test-Path -LiteralPath $recordPath)) 'Confirm=No created an image probe or changed the install'
        }
        Remove-Item -LiteralPath $dockerLog -Force
        function Get-CimInstance { param([string]$ClassName,[string]$ErrorAction) [pscustomobject]@{ExecutablePath=(Join-Path $singleInstall 'dist\AgentChannels.exe');ProcessId=4242;Name='AgentChannels.exe'} }
        try{$viewerBlocked=(& $installer @singleOptions -ReuseExistingBackendImage -DockerPath $fakeDocker -Apply|Out-String|ConvertFrom-Json)}
        finally{Microsoft.PowerShell.Management\Remove-Item -LiteralPath Function:\Get-CimInstance -Force}
        $viewerBlockedCalls=Get-Content -LiteralPath $dockerLog -Raw
        Assert-True ($viewerBlocked.status -eq 'blocked-process-in-use' -and -not $viewerBlocked.imageContentVerified -and $viewerBlockedCalls -notmatch '(^|\s)(create|cp|rm)(\s|$)' -and (Test-Path -LiteralPath $recordPath)) 'viewer-in-use path created an image probe or changed the install'
        Remove-Item -LiteralPath $dockerLog -Force
        $offlineUpgrade=(& $installer @singleOptions -ReuseExistingBackendImage -DockerPath $fakeDocker -LaunchAfterInstall -HealthAttempts 1 -Apply|Out-String|ConvertFrom-Json)
        Assert-True ($offlineUpgrade.status -eq 'installed' -and $offlineUpgrade.startStatus -eq 'started' -and $offlineUpgrade.backendImageAction -eq 'reuse-local-image') 'offline upgrade did not restart with existing image'
        $offlineCalls=Get-Content -LiteralPath $dockerLog -Raw
        Assert-True ($offlineCalls -match '--no-build --pull never' -and $offlineCalls -notmatch '--build') 'offline upgrade attempted build or implicit pull'
        Remove-Item Env:QICHENG_LITE_FAKE_OWNED_INSTALL
        Remove-Item Env:QICHENG_LITE_FAKE_IMAGE_APP
        $singleStarted=(& (Join-Path $singleInstall 'Start-Qicheng-Lite.ps1') -InstallRoot $singleInstall -NoWindowsChannels -DockerPath $fakeDocker -HealthAttempts 1|Out-String|ConvertFrom-Json)
        Assert-True ($singleStarted.status -eq 'started' -and $singleStarted.channelCount -eq 1 -and @($singleStarted.services).Count -eq 1 -and @($singleStarted.ports).Count -eq 1) 'single-channel start contract failed'
        $singleDiagnosis=(& (Join-Path $singleInstall 'Diagnose-Qicheng-Lite.ps1') -InstallRoot $singleInstall -DockerPath $fakeDocker -StartupRoot $singleOptions.StartupRoot -LegacyStartupRoot $singleOptions.LegacyStartupRoot|Out-String|ConvertFrom-Json)
        Assert-True ($singleDiagnosis.channelCount -eq 1 -and @($singleDiagnosis.ports).Count -eq 1 -and -not @($singleDiagnosis.checks|Where-Object{$_.name -match '18762'}).Count) 'single-channel diagnosis incorrectly checked port 18762'
        Assert-True (-not @($global:mockStateUris|Where-Object{$_ -match ':18762/'}).Count) 'single-channel start or diagnosis contacted port 18762'
        $env:QICHENG_LITE_FAKE_OLD_CHANNEL2_DIR=$singleInstall
        $singleStartedAgain=(& (Join-Path $singleInstall 'Start-Qicheng-Lite.ps1') -InstallRoot $singleInstall -NoWindowsChannels -DockerPath $fakeDocker -HealthAttempts 1|Out-String|ConvertFrom-Json)
        Assert-True ($singleStartedAgain.status -eq 'started' -and (Get-Content -LiteralPath $dockerLog -Raw) -match 'stop channel2') 'owned old channel2 was not stopped after selecting one channel'
        $env:QICHENG_LITE_FAKE_OLD_CHANNEL2_DIR=(Join-Path $testRoot 'foreign-install')
        $foreignError=''
        try{& (Join-Path $singleInstall 'Start-Qicheng-Lite.ps1') -InstallRoot $singleInstall -NoWindowsChannels -DockerPath $fakeDocker -HealthAttempts 1 -ErrorAction Stop|Out-Null}catch{$foreignError=$_.Exception.Message}
        Assert-True ($foreignError -match '目录不匹配') 'foreign channel2 container was not protected'
        Remove-Item Env:QICHENG_LITE_FAKE_OLD_CHANNEL2_DIR
    }else{
    $requestLog=Join-Path $testRoot 'requests.log';$readyFile=Join-Path $testRoot 'server.ready';$serverScript=Join-Path $testRoot 'fake-state-server.py'
    $authModeFile=Join-Path $testRoot 'input-auth.txt'
    Set-Content -LiteralPath $authModeFile -Value 'direct-v1' -NoNewline
    @'
import http.server,json,sys,threading,time
token,ready,log,auth_file=sys.argv[1:5]; ports=[int(x) for x in sys.argv[5:]]
class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def do_GET(self):
        if self.path=='/health': body={'service':'agent-channels'}
        elif self.path=='/api/state' and self.headers.get('Authorization')=='Bearer '+token:
            body={'input_target':'private-linux-display','input_auth':open(auth_file,encoding='utf-8').read().strip(),'channel_id':str(self.server.server_port-18760),'width':1600,'height':900,'mode':'paused'}
            with open(log,'a',encoding='utf-8') as f: f.write('authorized-state\n')
        else: self.send_response(401); self.end_headers(); return
        data=json.dumps(body).encode(); self.send_response(200); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
servers=[http.server.ThreadingHTTPServer(('127.0.0.1',p),Handler) for p in ports]
for server in servers: threading.Thread(target=server.serve_forever,daemon=True).start()
open(ready,'w').write('ready')
while True: time.sleep(1)
'@|Set-Content -LiteralPath $serverScript -Encoding UTF8
    $python=(Get-Command python.exe -ErrorAction Stop).Source
    $serverError=Join-Path $testRoot 'fake-state-server.err'
    $serverProcess=Start-Process -FilePath $python -ArgumentList @($serverScript,$token,$readyFile,$requestLog,$authModeFile,$port1,$port2) -WindowStyle Hidden -PassThru -RedirectStandardError $serverError
    foreach($n in 1..100){if((Test-Path -LiteralPath $readyFile) -or $serverProcess.HasExited){break};Start-Sleep -Milliseconds 100}
    Assert-True (Test-Path -LiteralPath $readyFile) ("fake state server did not start: "+$(if(Test-Path -LiteralPath $serverError){Get-Content -LiteralPath $serverError -Raw}else{'no stderr'}))
    }
    $fakeViewerSource=Join-Path $testRoot 'FakeViewer.cs'
    [IO.File]::WriteAllText($fakeViewerSource,'public static class FakeViewer { [System.STAThread] public static int Main(string[] args) { return 0; } }',[Text.UTF8Encoding]::new($false))
    $compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
    & $compiler /nologo /target:winexe /optimize+ "/out:$install\dist\AgentChannels.exe" $fakeViewerSource
    Assert-True ($LASTEXITCODE -eq 0) 'fake viewer compilation failed'
    & $compiler /nologo /target:winexe /optimize+ "/out:$singleInstall\dist\AgentChannels.exe" $fakeViewerSource
    Assert-True ($LASTEXITCODE -eq 0) 'single-channel fake viewer compilation failed'
    $probeOutput=Join-Path $testRoot 'fake-context.out';$probeError=Join-Path $testRoot 'fake-context.err'
    $probeProcess=Start-Process -FilePath $fakeDocker -ArgumentList @('context','inspect','--format','{{.Endpoints.docker.Host}}') -WindowStyle Hidden -PassThru -Wait -RedirectStandardOutput $probeOutput -RedirectStandardError $probeError
    Assert-True ($probeProcess.ExitCode -eq 0 -and (Get-Content -LiteralPath $probeOutput -Raw).Trim() -eq 'npipe:////./pipe/dockerDesktopLinuxEngine') ("fake Docker context fixture failed: "+(Get-Content -LiteralPath $probeOutput -Raw))
    $staleImageError=''
    try{& (Join-Path $install 'Start-Qicheng-Lite.ps1') -InstallRoot $install -Background -NoWindowsChannels -DockerPath $fakeDocker -HealthAttempts 1 -ErrorAction Stop|Out-Null}catch{$staleImageError=$_.Exception.Message}
    Assert-True ($staleImageError -match 'input_auth=broker-v2' -and $staleImageError -match '未启动查看器') 'old direct-input image was accepted in broker mode'
    Assert-True ((Get-Content -LiteralPath $dockerLog -Raw) -match 'stop channel1 channel2') 'stale broker backend was not stopped'
    if($RecoveryOnly){$env:QICHENG_TEST_INPUT_AUTH='broker-v2'}else{
        Set-Content -LiteralPath $authModeFile -Value 'broker-v2' -NoNewline
    }
    try{$started=(& (Join-Path $install 'Start-Qicheng-Lite.ps1') -InstallRoot $install -Background -BuildBackend -NoWindowsChannels -DockerPath $fakeDocker -HealthAttempts 3|Out-String|ConvertFrom-Json)}catch{throw ("isolated start failed; Docker calls: "+$(if(Test-Path -LiteralPath $dockerLog){Get-Content -LiteralPath $dockerLog -Raw}else{'none'})+"; error: "+$_.Exception.Message)}
    Assert-True ($started.status -eq 'started' -and $started.viewerMode -eq 'background') 'isolated start failed'
    $recoveryMarker=Join-Path $testRoot 'desktop-ready.marker'
    $desktopLog=Join-Path $testRoot 'desktop-start.log'
    $env:QICHENG_LITE_FAKE_DESKTOP_MARKER=$recoveryMarker
    $env:QICHENG_LITE_FAKE_DESKTOP_LOG=$desktopLog
    $recoveryDocker=$fakeDocker
    $desktopSource=Join-Path $testRoot 'FakeDesktop.cs'
    $desktopExe=Join-Path $testRoot 'FakeDesktop.exe'
    [IO.File]::WriteAllText($desktopSource,'public static class FakeDesktop { [System.STAThread] public static void Main() { System.IO.File.AppendAllText(System.Environment.GetEnvironmentVariable("QICHENG_LITE_FAKE_DESKTOP_LOG"), "started\n"); System.IO.File.WriteAllText(System.Environment.GetEnvironmentVariable("QICHENG_LITE_FAKE_DESKTOP_MARKER"), "ready"); System.Threading.Thread.Sleep(30000); } }',[Text.UTF8Encoding]::new($false))
    & $compiler /nologo /target:winexe /optimize+ "/out:$desktopExe" $desktopSource
    Assert-True ($LASTEXITCODE -eq 0) 'fake Desktop compilation failed'
    $env:QICHENG_LITE_FAKE_DOCKER_MODE='remote'
    $remoteError=''
    try{& (Join-Path $install 'Start-Qicheng-Lite.ps1') -InstallRoot $install -LoginRecovery -NoWindowsChannels -DockerPath $recoveryDocker -DockerDesktopPath $desktopExe -DockerReadyTimeoutSeconds 1 -ErrorAction Stop|Out-Null}catch{$remoteError=$_.Exception.Message}
    Assert-True ($remoteError -match 'endpoint.*本机' -and -not(Test-Path -LiteralPath $desktopLog)) 'remote Docker context was accepted or launched Desktop'
    $env:QICHENG_LITE_FAKE_DOCKER_MODE='context-fail'
    $contextError=''
    try{& (Join-Path $install 'Start-Qicheng-Lite.ps1') -InstallRoot $install -LoginRecovery -NoWindowsChannels -DockerPath $recoveryDocker -DockerDesktopPath $desktopExe -DockerReadyTimeoutSeconds 1 -ErrorAction Stop|Out-Null}catch{$contextError=$_.Exception.Message}
    Assert-True ($contextError -match '无法确认当前 Docker endpoint' -and -not(Test-Path -LiteralPath $desktopLog)) 'failed context inspect launched Desktop'
    $missingDockerError=''
    try{& (Join-Path $install 'Start-Qicheng-Lite.ps1') -InstallRoot $install -LoginRecovery -NoWindowsChannels -DockerPath (Join-Path $testRoot 'missing-docker.exe') -DockerDesktopPath $desktopExe -DockerReadyTimeoutSeconds 1 -ErrorAction Stop|Out-Null}catch{$missingDockerError=$_.Exception.Message}
    Assert-True ($missingDockerError -match '无法确认当前 Docker endpoint' -and -not(Test-Path -LiteralPath $desktopLog)) 'missing Docker CLI launched Desktop'
    $env:QICHENG_LITE_FAKE_DOCKER_MODE='windows'
    Set-Content -LiteralPath $recoveryMarker -Value 'ready' -NoNewline
    $windowsError=''
    try{& (Join-Path $install 'Start-Qicheng-Lite.ps1') -InstallRoot $install -LoginRecovery -NoWindowsChannels -DockerPath $recoveryDocker -DockerDesktopPath $desktopExe -DockerReadyTimeoutSeconds 1 -ErrorAction Stop|Out-Null}catch{$windowsError=$_.Exception.Message}
    Assert-True ($windowsError -match 'Windows 模式' -and -not(Test-Path -LiteralPath $desktopLog)) 'Windows engine was accepted or launched Desktop'
    Remove-Item -LiteralPath $recoveryMarker -Force
    $env:QICHENG_LITE_FAKE_DOCKER_MODE='hang'
    $hangTimer=[Diagnostics.Stopwatch]::StartNew();$hangError=''
    try{& (Join-Path $install 'Start-Qicheng-Lite.ps1') -InstallRoot $install -LoginRecovery -NoWindowsChannels -DockerPath $recoveryDocker -DockerDesktopPath $desktopExe -DockerReadyTimeoutSeconds 1 -ErrorAction Stop|Out-Null}catch{$hangError=$_.Exception.Message}
    $hangTimer.Stop()
    Assert-True ($hangError -match '无法确认当前 Docker endpoint' -and $hangTimer.ElapsedMilliseconds -lt 2500 -and -not(Test-Path -LiteralPath $desktopLog)) "hanging Docker probe exceeded budget or opened Desktop ($($hangTimer.ElapsedMilliseconds) ms)"
    Remove-Item Env:QICHENG_LITE_FAKE_DOCKER_MODE
    $manualError=''
    try{& (Join-Path $install 'Start-Qicheng-Lite.ps1') -InstallRoot $install -NoWindowsChannels -DockerPath $recoveryDocker -DockerDesktopPath $desktopExe -DockerReadyTimeoutSeconds 2 -HealthAttempts 1 -ErrorAction Stop|Out-Null}catch{$manualError=$_.Exception.Message}
    Assert-True ($manualError -match 'Docker Linux engine' -and -not(Test-Path -LiteralPath $desktopLog)) 'manual start did not fail without opening Desktop'
    $recovered=(& (Join-Path $install 'Start-Qicheng-Lite.ps1') -InstallRoot $install -Background -LoginRecovery -NoWindowsChannels -DockerPath $recoveryDocker -DockerDesktopPath $desktopExe -DockerReadyTimeoutSeconds 3 -HealthAttempts 3|Out-String|ConvertFrom-Json)
    Assert-True ($recovered.status -eq 'started' -and (Test-Path -LiteralPath $recoveryMarker)) 'login recovery did not start fake Desktop and restore Lite'
    Assert-True (@(Get-Content -LiteralPath $desktopLog).Count -eq 1) 'login recovery launched Desktop more than once'
    Remove-Item -LiteralPath $recoveryMarker -Force
    $timeoutError=''
    try{& (Join-Path $install 'Start-Qicheng-Lite.ps1') -InstallRoot $install -Background -LoginRecovery -NoWindowsChannels -DockerPath $recoveryDocker -DockerDesktopPath $desktopExe -DockerReadyTimeoutSeconds 1 -HealthAttempts 1 -ErrorAction Stop|Out-Null}catch{$timeoutError=$_.Exception.Message}
    Assert-True ($timeoutError -match '等待上限 1 秒' -and @(Get-Content -LiteralPath $desktopLog).Count -eq 1) ("login recovery timeout or existing Desktop process guard failed: error=$timeoutError; starts="+@(Get-Content -LiteralPath $desktopLog).Count)
    Assert-True ((Get-Content -LiteralPath $dockerLog -Raw) -notmatch '(^|\s)down(\s|$)|(^|\s)-v(\s|$)') 'recovery attempted destructive Docker action'
    foreach($desktopProcess in @(Get-TestOwnedProcesses -Root $testRoot|Where-Object{$_.ExecutablePath -eq $desktopExe})){Stop-Process -Id ([int]$desktopProcess.ProcessId) -Force -ErrorAction SilentlyContinue}
    foreach($n in 1..20){if(-not @(Get-TestOwnedProcesses -Root $testRoot).Count){break};Start-Sleep -Milliseconds 50}
    Assert-True (@(Get-TestOwnedProcesses -Root $testRoot).Count -eq 0) 'fake viewer did not exit after isolated start'
    if($RecoveryOnly){
        $exportMock=Join-Path $testRoot 'export-ownership-mock.ps1'
        $exportLog=Join-Path $testRoot 'export-ownership.log'
        $env:QICHENG_LITE_EXPORT_DOCKER_LOG=$exportLog
        @'
param([Parameter(ValueFromRemainingArguments=$true)][string[]]$DockerArgs)
Add-Content -LiteralPath $env:QICHENG_LITE_EXPORT_DOCKER_LOG -Value ($DockerArgs -join ' ')
if($DockerArgs[0] -eq 'version'){'1.0';return}
if($DockerArgs[0] -eq 'compose' -and $DockerArgs -contains '-q'){'qicheng-test-channel1';return}
if($DockerArgs[0] -eq 'inspect'){
    if($DockerArgs[2] -match 'compose.project.working_dir'){$env:QICHENG_LITE_EXPORT_WORKING_DIR}
    elseif($DockerArgs[2] -match 'compose.project'){'qicheng-agent-channels'}
    else{'channel1'}
    return
}
if($DockerArgs[0] -eq 'cp'){
    New-Item -ItemType Directory -Path $DockerArgs[-1] -Force|Out-Null
    Set-Content -LiteralPath (Join-Path $DockerArgs[-1] 'sample.txt') -Value 'owned-download' -NoNewline
    return
}
throw 'Unexpected fake Docker arguments'
'@|Set-Content -LiteralPath $exportMock -Encoding UTF8
        $env:QICHENG_LITE_EXPORT_WORKING_DIR=$singleInstall
        $ownedExport=(& (Join-Path $singleInstall 'Export-Downloads.ps1') -Channel 1 -InstallRoot $singleInstall -DockerPath $exportMock|Out-String|ConvertFrom-Json)
        Assert-True ($ownedExport.status -eq 'exported' -and $ownedExport.ownContainerVerified -and (Test-Path -LiteralPath (Join-Path $ownedExport.destination 'sample.txt'))) 'owned installation download export failed'
        $env:QICHENG_LITE_EXPORT_WORKING_DIR=(Join-Path $testRoot 'foreign-install')
        Remove-Item -LiteralPath $exportLog -Force
        $foreignExportError=''
        try{& (Join-Path $singleInstall 'Export-Downloads.ps1') -Channel 1 -InstallRoot $singleInstall -DockerPath $exportMock -ErrorAction Stop|Out-Null}catch{$foreignExportError=$_.Exception.Message}
        Assert-True ($foreignExportError -match '容器归属验证失败' -and (Get-Content -LiteralPath $exportLog -Raw) -notmatch '(^|\s)cp(\s|$)') 'foreign installation download was not rejected before copy'
        [ordered]@{schemaVersion=1;status='passed';loginRecovery=$true;manualFastFailure=$true;desktopSingleInstance=$true;boundedTimeout=$true;hangingProbeBounded=$true;remoteContextRejected=$true;unknownContextRejected=$true;missingDockerCliRejected=$true;windowsEngineRejected=$true;realDockerTouched=$false;realDesktopTouched=$false;realStartupTouched=$false}|ConvertTo-Json -Depth 4
        return
    }
    $requests=@(Get-Content -LiteralPath $requestLog)
    Assert-True ($requests.Count -ge 2) 'authenticated state was not checked for both channels'
    $dockerCalls=Get-Content -LiteralPath $dockerLog -Raw
    Assert-True ($dockerCalls -match '--project-name qicheng-agent-channels' -and $dockerCalls -match '--profile second' -and $dockerCalls -match 'channel1 channel2' -and $dockerCalls -match '--build' -and $dockerCalls -match 'compose\.broker\.yaml') 'broker compose start contract failed'
    Assert-True ($dockerCalls -notmatch '(^|\s)down(\s|$)|(^|\s)-v(\s|$)') 'start attempted destructive Docker action'

    Remove-Item -LiteralPath $dockerLog -Force
    $diagnosisText=(& (Join-Path $install 'Diagnose-Qicheng-Lite.ps1') -InstallRoot $install -DockerPath $fakeDocker -StartupRoot $startup -LegacyStartupRoot $legacyStartup|Out-String)
    Assert-True ($diagnosisText -notmatch [regex]::Escape($token)) 'diagnosis exposed token'
    $diagnosis=$diagnosisText|ConvertFrom-Json
    Assert-True (-not $diagnosis.mutationsMade -and -not $diagnosis.tokenDisplayed) 'diagnosis mutation contract failed'
    $ps5Diagnosis=(& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $install 'Diagnose-Qicheng-Lite.ps1') -DockerPath $fakeDocker -StartupRoot $startup -LegacyStartupRoot $legacyStartup|Out-String|ConvertFrom-Json)
    Assert-True ([IO.Path]::GetFullPath([string]$ps5Diagnosis.installRoot) -eq [IO.Path]::GetFullPath($install) -and $ps5Diagnosis.mutationsMade -eq $false) 'Windows PowerShell 5.1 diagnosis did not derive its script root'
    $diagnoseCalls=Get-Content -LiteralPath $dockerLog -Raw
    Assert-True ($diagnoseCalls -match 'compose .* ps' -and $diagnoseCalls -notmatch '(^|\s)up(\s|$)|(^|\s)down(\s|$)|(^|\s)-v(\s|$)') 'diagnosis used mutating Docker command'

    $exportDocker=Join-Path $testRoot 'fake-export-docker.ps1';$exportDockerLog=Join-Path $testRoot 'export-docker.log';$env:QICHENG_LITE_EXPORT_DOCKER_LOG=$exportDockerLog
    @'
param([Parameter(ValueFromRemainingArguments=$true)][string[]]$DockerArgs)
Add-Content -LiteralPath $env:QICHENG_LITE_EXPORT_DOCKER_LOG -Value ($DockerArgs -join ' ')
if($DockerArgs[0] -eq 'version'){'1.0';return}
if($DockerArgs[0] -eq 'compose' -and $DockerArgs -contains '-q'){'qicheng-test-channel1';return}
if($DockerArgs[0] -eq 'inspect'){
    if($DockerArgs[2] -match 'compose.project.working_dir'){$env:QICHENG_LITE_EXPORT_WORKING_DIR}
    elseif($DockerArgs[2] -match 'compose.project'){'qicheng-agent-channels'}
    else{'channel1'}
    return
}
if($DockerArgs[0] -eq 'cp'){
    $destination=$DockerArgs[-1]
    New-Item -ItemType Directory -Path $destination -Force|Out-Null
    Set-Content -LiteralPath (Join-Path $destination 'sample.txt') -Value 'guest-download' -NoNewline
    return
}
throw 'Unexpected fake Docker arguments'
'@|Set-Content -LiteralPath $exportDocker -Encoding UTF8
    $env:QICHENG_LITE_EXPORT_WORKING_DIR=$install
    $downloadText=(& (Join-Path $install 'Export-Downloads.ps1') -Channel 1 -InstallRoot $install -DataRoot $data -DockerPath $exportDocker|Out-String)
    Assert-True ($downloadText -notmatch [regex]::Escape($token)) 'download export exposed token'
    $download=$downloadText|ConvertFrom-Json
    Assert-True ($download.status -eq 'exported' -and $download.ownContainerVerified -and $download.guestFilesPreserved -and -not $download.volumesRemoved) 'download snapshot contract failed'
    Assert-True ((Get-Content -LiteralPath (Join-Path $download.destination 'sample.txt') -Raw) -eq 'guest-download') 'download snapshot file missing'
    $exportCalls=Get-Content -LiteralPath $exportDockerLog -Raw
    Assert-True ($exportCalls -match 'qicheng-test-channel1:/home/channel/Downloads/\.' -and $exportCalls -notmatch '(^|\s)rm(\s|$)|(^|\s)down(\s|$)|(^|\s)-v(\s|$)') 'download export Docker contract failed'
    $env:QICHENG_LITE_EXPORT_WORKING_DIR=(Join-Path $testRoot 'foreign-install')
    Remove-Item -LiteralPath $exportDockerLog -Force
    $foreignExportError=''
    try{& (Join-Path $install 'Export-Downloads.ps1') -Channel 1 -InstallRoot $install -DataRoot $data -DockerPath $exportDocker -ErrorAction Stop|Out-Null}catch{$foreignExportError=$_.Exception.Message}
    Assert-True ($foreignExportError -match '容器归属验证失败' -and (Get-Content -LiteralPath $exportDockerLog -Raw) -notmatch '(^|\s)cp(\s|$)') 'foreign installation download was not rejected before copy'
    $env:QICHENG_LITE_EXPORT_WORKING_DIR=$install

    $ps5Install=Join-Path $testRoot 'installed-ps5';$ps5Data=Join-Path $testRoot 'data-ps5';$ps5Script=Join-Path $testRoot 'ps5-install.ps1'
    $ps5Command='& '+(Quote-Ps $installer)+' -PackageRoot '+(Quote-Ps $build.windows.directory)+' -InstallRoot '+(Quote-Ps $ps5Install)+' -DataRoot '+(Quote-Ps $ps5Data)+' -StartMenuRoot '+(Quote-Ps (Join-Path $testRoot 'ps5-menu'))+' -DesktopRoot '+(Quote-Ps (Join-Path $testRoot 'ps5-desktop'))+' -StartupRoot '+(Quote-Ps (Join-Path $testRoot 'ps5-startup'))+' -LegacyStartupRoot '+(Quote-Ps (Join-Path $testRoot 'ps5-legacy'))+' -ImportTokenPath '+(Quote-Ps $tokenPath)+' -Apply -Confirm:$false'
    [IO.File]::WriteAllText($ps5Script,$ps5Command,[Text.UTF8Encoding]::new($true))
    $ps5Text=(& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $ps5Script|Out-String)
    Assert-True ($LASTEXITCODE -eq 0 -and (($ps5Text|ConvertFrom-Json).status -eq 'installed')) 'Windows PowerShell 5.1 install/ACL branch failed'

    $publicRoot=Join-Path $testRoot 'public';New-Item -ItemType Directory -Path $publicRoot|Out-Null
    $export=(& (Join-Path $productRoot 'Export-PublicSource.ps1') -OutputDirectory $publicRoot|Out-String|ConvertFrom-Json)
    Assert-True ($export.status -eq 'exported' -and $export.fileCount -eq $sourcePaths.Count) 'public source export failed'
    $publicManifest=Read-Json (Join-Path $publicRoot 'QICHENG-LITE-PUBLIC-SOURCE-MANIFEST.json')
    Assert-True ($null -eq $publicManifest.repositoryCommit) 'public export leaked private Git commit'
    foreach($entry in @($publicManifest.files)){Assert-True ((Get-FileHash -LiteralPath (Join-Path $publicRoot ([string]$entry.path)) -Algorithm SHA256).Hash.ToLowerInvariant() -eq [string]$entry.sha256) "public export hash mismatch: $($entry.path)"}
    if(-not $SkipPublicRoundTrip){
        $roundtrip=Join-Path $testRoot 'public-packages'
        $rebuilt=(& (Join-Path $publicRoot 'tools\agent-channels\product\Build-Package.ps1') -OutputDirectory $roundtrip|Out-String|ConvertFrom-Json)
        Assert-True ($rebuilt.status -eq 'built' -and (Test-Path -LiteralPath $rebuilt.windows.archive) -and -not $rebuilt.linuxHostReleaseBuilt) 'public source roundtrip build failed'
    }

    [ordered]@{schemaVersion=1;status='passed';version=$build.version;packageFiles=$build.windows.files;sourceFiles=$sourcePaths.Count;viewerSelfTest=$true;windowsPowerShell51Install=$true;isolatedDockerContract=$true;publicExportRoundTrip=(-not $SkipPublicRoundTrip);realDockerTouched=$false;realStartupTouched=$false;realInstallTouched=$false}|ConvertTo-Json -Depth 5
}finally{
    if($serverProcess -and -not $serverProcess.HasExited){Stop-Process -Id $serverProcess.Id -Force -ErrorAction SilentlyContinue}
    foreach($process in @(Get-TestOwnedProcesses -Root $testRoot)){
        if([int]$process.ProcessId -ne $PID){Stop-Process -Id ([int]$process.ProcessId) -Force -ErrorAction SilentlyContinue}
    }
    Remove-Item Env:QICHENG_LITE_FAKE_DOCKER_LOG -ErrorAction SilentlyContinue
    Remove-Item Env:QICHENG_LITE_FAKE_IMAGE_APP -ErrorAction SilentlyContinue
    Remove-Item Env:QICHENG_LITE_FAKE_OWNED_INSTALL -ErrorAction SilentlyContinue
    Remove-Item Env:QICHENG_LITE_FAKE_DOCKER_MODE -ErrorAction SilentlyContinue
    Remove-Item Env:QICHENG_LITE_FAKE_DESKTOP_MARKER -ErrorAction SilentlyContinue
    Remove-Item Env:QICHENG_LITE_FAKE_DESKTOP_LOG -ErrorAction SilentlyContinue
    Remove-Item Env:QICHENG_LITE_EXPORT_DOCKER_LOG -ErrorAction SilentlyContinue
    Remove-Item Env:QICHENG_LITE_EXPORT_WORKING_DIR -ErrorAction SilentlyContinue
    Remove-Item Env:QICHENG_TEST_INPUT_AUTH -ErrorAction SilentlyContinue
    Remove-Item Env:QICHENG_LITE_FAKE_OLD_CHANNEL2_DIR -ErrorAction SilentlyContinue
    Remove-Variable -Name mockStateUris -Scope Global -ErrorAction SilentlyContinue
    if(Test-Path -LiteralPath $testRoot){Remove-Item -LiteralPath $testRoot -Recurse -Force -ErrorAction SilentlyContinue}
}

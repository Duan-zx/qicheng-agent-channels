[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$LogPath,
    [string]$InstallerPath,
    [string]$PackageRoot,
    [string]$PowerShellPath
)

# Keep the installer in its own process: its exit statement must not bypass
# logging or the CMD entry point's final receipt check.
$ErrorActionPreference = 'Continue'
try {
    [IO.File]::WriteAllText($LogPath, '')
    if ([string]::IsNullOrWhiteSpace($InstallerPath)) { $InstallerPath = Join-Path $PSScriptRoot 'Qicheng-Lite\Install-Qicheng-Lite.ps1' }
    if ([string]::IsNullOrWhiteSpace($PackageRoot)) { $PackageRoot = Join-Path $PSScriptRoot 'Qicheng-Lite' }
    if ([string]::IsNullOrWhiteSpace($PowerShellPath)) { $PowerShellPath = Join-Path $PSHOME 'powershell.exe' }
    if (-not (Test-Path -LiteralPath $InstallerPath -PathType Leaf)) {
        throw "Installer script is missing: $InstallerPath"
    }

    & $PowerShellPath -NoProfile -ExecutionPolicy Bypass -File $InstallerPath -PackageRoot $PackageRoot -DesktopApp wechat -ChannelCount 2 -LaunchAfterInstall -NonInteractive -Apply 2>&1 |
        Tee-Object -FilePath $LogPath -ErrorAction Stop
    $result = $LASTEXITCODE
    if ($null -eq $result) { throw 'Installer did not return an exit code.' }
    exit $result
} catch {
    $message = 'Installer could not start: ' + $_.Exception.Message
    Write-Host $message
    try { [IO.File]::AppendAllText($LogPath, $message + [Environment]::NewLine) } catch { }
    exit 1
}
